export interface AuthenticityAnalysis {
  status: 'ok' | 'unavailable' | string;
  verdict?: 'human' | 'synthetic' | 'uncertain';
  humanProbability?: number;
  syntheticProbability?: number;
  confidence?: 'high' | 'medium' | 'low' | string;
  modelId?: string;
  reason?: string;
}

export interface LanguageAnalysis {
  status: 'ok' | 'unavailable' | string;
  code?: string;
  label?: string;
  confidence?: number;
  modelId?: string;
  reason?: string;
}

export interface AccentAnalysis {
  status: 'ok' | 'unavailable' | string;
  code?: string;
  label?: string;
  reason?: string;
  modelId?: string | null;
  confidence?: number;
}

export interface NoiseSuppressionData {
  active: boolean;
  isolatedVoiceRatio?: number;
  noiseReductionDb?: number;
  snrDb?: number;
  vocalFrequencyIsolation?: string;
}

export interface AudioQualityData {
  durationSeconds: number;
  rms: number;
  clippingRatio: number;
  silenceRatio: number;
  sufficientSpeech: boolean;
  noiseSuppression?: NoiseSuppressionData;
}

export interface RuntimeData {
  device: string;
  latencyMs: number;
}

export interface AnalysisResponsePayload {
  ok: boolean;
  id: string;
  createdAt: string;
  originalFilename?: string;
  storedFilename?: string;
  analysis: {
    authenticity: AuthenticityAnalysis;
    language: LanguageAnalysis;
    accent: AccentAnalysis;
  };
  quality: AudioQualityData;
  runtime: RuntimeData;
}

export interface AnalysisSummaryItem {
  id: string;
  createdAt: string;
  filename: string;
  authenticityVerdict: 'human' | 'synthetic' | 'uncertain' | string;
  humanProbability: number | null;
  syntheticProbability: number | null;
  language: string | null;
  accent: string | null;
}

export interface AnalysisListResponse {
  items: AnalysisSummaryItem[];
}

export interface LocalAudioMetrics {
  durationSeconds: number;
  sampleRate: number;
  channelCount: number;
  rms: number;
  peakAmplitude: number;
  clippingRatio: number;
  silenceRatio: number;
  fileName: string;
  fileSize: number;
  noiseSuppression?: NoiseSuppressionData;
}

export interface StatusCheckResponse {
  ok: boolean;
  pythonWorker: 'running' | 'unavailable' | string;
  device: string;
  authenticityModelLoaded: boolean;
  languageModelLoaded: boolean;
  accentModelLoaded: boolean;
  resultCount: number;
  workerError?: string | null;
}

export type UIState = 
  | 'idle' 
  | 'recording' 
  | 'processing' 
  | 'insufficient_speech' 
  | 'human' 
  | 'synthetic' 
  | 'uncertain' 
  | 'local_analyzed'
  | 'api_error';
