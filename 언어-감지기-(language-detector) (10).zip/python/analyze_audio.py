import sys
import os
import json
import argparse
from pipeline import VoxShieldPipeline

def main():
    parser = argparse.ArgumentParser(description="Analyze audio file with VoxShield pipeline")
    parser.add_argument("--audio", required=True, help="Path to audio file")
    parser.add_argument("--output", required=False, help="Path to save result JSON")
    parser.add_argument("--id", required=False, help="Request ID")
    args = parser.parse_args()

    if not os.path.exists(args.audio):
        err_res = {
            "ok": False,
            "code": "FILE_NOT_FOUND",
            "message": f"Audio file not found: {args.audio}"
        }
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(err_res, f, indent=2)
        print(json.dumps(err_res))
        sys.exit(1)

    pipeline = VoxShieldPipeline()
    result = pipeline.process_file(args.audio, req_id=args.id)

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)

    print(json.dumps(result))

if __name__ == "__main__":
    main()
