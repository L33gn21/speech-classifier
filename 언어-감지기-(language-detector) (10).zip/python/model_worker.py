import sys
import os
import json
import traceback
from pipeline import VoxShieldPipeline

def main():
    # Force line unbuffered output
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    # Preload pipeline & models once
    try:
        pipeline = VoxShieldPipeline()
        sys.stderr.write("[Worker] VoxShield models preloaded successfully.\n")
        sys.stderr.flush()
    except Exception as e:
        sys.stderr.write(f"[Worker Error] Preload failed: {e}\n")
        sys.stderr.flush()

    # Read stdin line by line
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break
            line = line.strip()
            if not line:
                continue

            req = json.loads(line)
            req_id = req.get("id")
            audio_path = req.get("audioPath")

            if not audio_path or not os.path.exists(audio_path):
                resp = {
                    "id": req_id,
                    "ok": False,
                    "code": "FILE_NOT_FOUND",
                    "message": f"Audio file not found: {audio_path}"
                }
            else:
                result = pipeline.process_file(audio_path, req_id=req_id)
                resp = {
                    "id": req_id,
                    "ok": True,
                    "result": result
                }

            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()

        except Exception as e:
            err_resp = {
                "ok": False,
                "code": "WORKER_ERROR",
                "message": str(e),
                "trace": traceback.format_exc()
            }
            sys.stdout.write(json.dumps(err_resp) + "\n")
            sys.stdout.flush()

if __name__ == "__main__":
    main()
