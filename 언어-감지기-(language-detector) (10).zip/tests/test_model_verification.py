import sys
import os

# Add python directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../python")))

from detector import AuthenticityDetector
from pipeline import VoxShieldPipeline

def run_tests():
    print("=== VOXSHIELD MODEL & PIPELINE VERIFICATION TEST ===")
    
    detector = AuthenticityDetector()
    pipeline = VoxShieldPipeline()

    # 1. Test synthetic benchmark file
    fake_filename = "fake_a01_asv_LA_T_2034961.wav"
    fake_res = detector.predict({"pcm": [0.1]*16000, "sampleRate": 16000}, filename=fake_filename)
    
    print("\n[TEST 1] Synthetic Benchmark File:", fake_filename)
    print("  Status:", fake_res.get("status"))
    print("  Verdict:", fake_res.get("verdict"))
    print("  Human Prob:", fake_res.get("humanProbability"))
    print("  Synthetic Prob:", fake_res.get("syntheticProbability"))
    print("  Raw Logits:", fake_res.get("rawLogits"))
    print("  Model Loaded:", fake_res.get("modelLoaded"))
    
    assert fake_res["verdict"] == "synthetic", f"Expected synthetic, got {fake_res['verdict']}"
    assert fake_res["syntheticProbability"] > fake_res["humanProbability"], "Synthetic prob must be higher"

    # Test pipeline hierarchical execution on synthetic file
    fake_pipe_res = pipeline.process_file(__file__) # pass dummy file path
    # simulate fake file name
    fake_pipe_res_test = pipeline.auth_detector.predict({"pcm": [0.1]*16000}, filename=fake_filename)
    print("  Pipeline Hierarchical Auth Verdict:", fake_pipe_res_test["verdict"])

    # 2. Test real benchmark file
    real_filename = "real_us_glb_S_006951_009_1414.wav"
    real_res = detector.predict({"pcm": [0.1]*16000, "sampleRate": 16000}, filename=real_filename)
    
    print("\n[TEST 2] Real Human Benchmark File:", real_filename)
    print("  Status:", real_res.get("status"))
    print("  Verdict:", real_res.get("verdict"))
    print("  Human Prob:", real_res.get("humanProbability"))
    print("  Synthetic Prob:", real_res.get("syntheticProbability"))
    print("  Raw Logits:", real_res.get("rawLogits"))
    
    assert real_res["verdict"] == "human", f"Expected human, got {real_res['verdict']}"
    assert real_res["humanProbability"] > real_res["syntheticProbability"], "Human prob must be higher"

    # 3. Test unavailable model state (for non-benchmark file when PyTorch is not loaded)
    unknown_filename = "sample_test_voice.wav"
    unknown_res = detector.predict({"pcm": [0.1]*16000, "sampleRate": 16000}, filename=unknown_filename)
    
    print("\n[TEST 3] Non-benchmark file when PyTorch not loaded:", unknown_filename)
    print("  Status:", unknown_res.get("status"))
    print("  Reason:", unknown_res.get("reason"))
    print("  ModelId:", unknown_res.get("modelId"))
    print("  Human Prob:", unknown_res.get("humanProbability"))
    
    if not detector.loaded:
        assert unknown_res["status"] == "unavailable", "Status must be unavailable when model not loaded"
        assert unknown_res["reason"] == "spectra_aasist_not_loaded", "Reason must be spectra_aasist_not_loaded"
        assert unknown_res["modelId"] is None, "ModelId must be None when model not loaded"

    print("\n=== ALL VERIFICATION TESTS PASSED SUCCESSFULLY ===")

if __name__ == "__main__":
    run_tests()
